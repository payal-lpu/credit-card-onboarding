package com.payal.spring.hibernate.ctrl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.payal.spring.hibernate.pojo.User;
import com.payal.spring.hibernate.pojo.User2;
import com.payal.spring.hibernate.service.AuthService;

@Component
@Controller
@RequestMapping("/datamatching")
public class FormContrl
{
	HibernateTemplate hibernateTemplate;
    @Autowired
    private AuthService authenticateService;            // This will auto-inject the authentication service into the controller.
 
 
    // Checks if the user credentials are valid or not.
    @SuppressWarnings({ "deprecation", "rawtypes" })
	@RequestMapping(value = "/match", method = RequestMethod.POST)
    public ModelAndView validateUser(@RequestParam("firstname")String firstname, @RequestParam("lastname")String lastname, @RequestParam("phone")String phone,@RequestParam("username")String username) {
    
    	
       
        List<User2> isValid = new ArrayList<User2>();
        	isValid =	authenticateService.validateUserfromDatabase(firstname, phone);
        	
       for(User2 obj : isValid)
       {
    	   System.out.println(obj.getLastname());
       }
        
        if(isValid.size()>0)
        {
        	authenticateService.xyz(username,"Accepted");
        	return new ModelAndView("successorerror", "output", "You have succesfully applied for the Credit Card! <br/> Login again and check the status");
        }
        
        else
        {
        	authenticateService.xyz(username, "Rejected");
        	return new ModelAndView("successorerror", "output", "Data filled is not correct and the session is terminated so login again and then enter the correct details!");
        }
    }
}
