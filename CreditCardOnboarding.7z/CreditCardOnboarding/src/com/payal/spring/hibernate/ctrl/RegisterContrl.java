package com.payal.spring.hibernate.ctrl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


import com.payal.spring.hibernate.service.AuthService;

@Component
@Controller
@RequestMapping("/register")
public class RegisterContrl {
 
    @Autowired
    private AuthService authenticateService;            // This will auto-inject the authentication service into the controller.
    // Checks if the user credentials are valid or not.
    @RequestMapping(value = "/registerUser", method = RequestMethod.POST)
    public ModelAndView registerUser(@RequestParam("id")String id,@RequestParam("firstname")String firstname, @RequestParam("lastname")String lastname, @RequestParam("phone")String phone,@RequestParam("username")String username,@RequestParam("password")String password)
    {
      ModelAndView mv=new ModelAndView();
      String s=authenticateService.registerIntoDataBase(id,firstname, lastname,phone,username,password);
      
      mv.setViewName(s);
      return mv;
    }
}
