package com.payal.spring.hibernate.ctrl;
 
import java.util.List;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.http.HttpRequest;
 
import com.payal.spring.hibernate.service.AuthService;
 
@Component
@Controller
@RequestMapping("/user")
public class LoginCntrl {
 
    @Autowired
    private AuthService authenticateService;            // This will auto-inject the authentication service into the controller.
    String user;
    private static Logger log = Logger.getLogger(LoginCntrl.class);
 
    // Checks if the user credentials are valid or not.
    @RequestMapping(value = "/validate", method = RequestMethod.POST)
    public ModelAndView validateUsr(HttpServletRequest request,@RequestParam("username")String username, @RequestParam("password")String password) {
        String msg = "";
        user=username;
        boolean isValid = authenticateService.findUser(username, password);
        log.info("Is user valid?= " + isValid);
        
        System.out.println("In the controller..");
 
        if(isValid) {
            msg = "Welcome " + username + "!";
            request.getSession().setAttribute("userid",username);  
            String s=authenticateService.getStatus(username);
            request.getSession().setAttribute("status",s);
           } else {
            msg = "Invalid credentials";
            return new ModelAndView("successorerror", "output", msg);
        }
 
        return new ModelAndView("choice", "output", msg);
    }
    
    @RequestMapping(value = "/home")
    public ModelAndView viewStatus()
    {
       
       ModelAndView mv=new ModelAndView();
       mv.setViewName("status");
       return mv;
    }
    
    @RequestMapping(value = "/result")
    public ModelAndView viewApplicationForm()
    {
       
       ModelAndView mv=new ModelAndView();
       mv.setViewName("result");
       return mv;
    }
    
    @RequestMapping(value = "/login")
    public ModelAndView LoginAgain()
    {
       
       ModelAndView mv=new ModelAndView();
       mv.setViewName("home");
       return mv;
    }
    
    @RequestMapping(value = "/choice1")
    public String Choice()
    {
    	return "choice";
    }
    
    @RequestMapping(value = "/result1")
    public ModelAndView Result()
    {
    	ModelAndView mv=new ModelAndView();
    	String status=authenticateService.getStatus(user);
    	System.out.println("status");
    	if(status.equals("Accepted"))
    	{
    		mv.setViewName("AppliedAlready");
    	}
    	
    	else
    	{
    		mv.setViewName("result");
    	}
    	return mv;
    }
}