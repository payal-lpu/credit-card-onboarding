package com.payal.spring.hibernate.service;

import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.springframework.orm.hibernate5.HibernateTemplate;

import com.payal.spring.hibernate.pojo.User;
import com.payal.spring.hibernate.pojo.User2;
 
public class AuthService {
 
    private HibernateTemplate hibernateTemplate;
    
    private static Logger log = Logger.getLogger(AuthService.class);
 
    private AuthService() { }
 
    public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
        this.hibernateTemplate = hibernateTemplate;
    }
 
    @SuppressWarnings( { "unchecked", "deprecation" } )
    public boolean findUser(String uname, String upwd) {
        log.info("Checking the user in the database");
        boolean isValidUser = false;
        //String sqlQuery = "from User where name='"+uname + "' and password='"+upwd+"'";
        String sqlQuery = "from User u where u.name=? and u.password=?";
        System.out.println("In the authentication service...user entered data " + uname + " pwd "+upwd);
        
        try {
			List<User> userObj = (List) hibernateTemplate.find(sqlQuery, uname, upwd);
            
            if(userObj != null)
            {
            	System.out.println("userObject is not null... ");
                for (User obj : userObj)
                {
                    System.out.println("Id "+obj.getId() + 
                       " Name " + obj.getName() + 
                       " Editor "+obj.getPassword());
                            
                }

            }
            
            
            
            if(userObj != null && userObj.size() > 0) {
                //log.info("Id= " + userObj.get(0)).getId() + ", Name= " + userObj.get(0).getName() + ", Password= " + userObj.get(0).getPassword());
                isValidUser = true;
            }
        } catch(Exception e) {
            isValidUser = false;
            log.error("An error occurred while fetching the user details from the database", e);    
        }
        return isValidUser;
    }
    
    public List<User2> validateUserfromDatabase(String firstname,String phone)
    {
    	
        String sqlQuery = "from User2 u where u.firstname=? and u.phone=?";
     
        
      
			List<User2> userObj = (List) hibernateTemplate.find(sqlQuery, firstname, phone);
            
           System.out.println("size :"+userObj.size());
                return userObj;
     }
    
    public String registerIntoDataBase(String id,String firstname,String lastname,String phone,String username,String password)
    {
    	Session session = hibernateTemplate.getSessionFactory().openSession();
    	String sqlQuery1="select firstname from User2 where phone=? OR username=?";
    	session.beginTransaction();
    	Query q=session.createQuery(sqlQuery1);
    	q.setParameter(0, phone);
    	q.setParameter(1, username);
    	List result=q.list();
    	if(result.size()>0)
    	{
    		System.out.println("User already registered");
    		return "AlreadyRegistered";
    	}
    	
    	else
    	{
    		System.out.println(firstname);
    		System.out.println(lastname);
    		System.out.println(phone);
    		System.out.println(username);
    		
    		User2 obj=new User2();
        	
        	obj.setFirstname(firstname);
        	obj.setLastname(lastname);
        	obj.setPhone(phone);
        	obj.setUsername(username);
        	hibernateTemplate.save(obj);
        	
        	User obj1=new User();
        	obj1.setName(username);
        	obj1.setPassword(password);
        	hibernateTemplate.save(obj1); 
        	
        	return "registered";
    	}    	
    }
    
    @SuppressWarnings("deprecation")
	public void xyz(int id1,String status)
    {
    	System.out.print("HEllo");
    	Session session = hibernateTemplate.getSessionFactory().openSession();
    	System.out.println("Current session "+session);
    	
    	 String sqlQuery1 = "update user1 SET status=? WHERE id=?";
    	 
    	 session.beginTransaction();

    	 @SuppressWarnings("rawtypes")
		SQLQuery insertQuery = session.createSQLQuery(sqlQuery1);
    	
    	insertQuery.setParameter(0,status);
    	insertQuery.setParameter(1,id1);     	 
    	 insertQuery.executeUpdate();
    	 session.getTransaction().commit();
    }
    
    public String getStatus(String username)
    {
    	Session session = hibernateTemplate.getSessionFactory().openSession();
    	String sqlQuery1="select status from User where name=?";
    	session.beginTransaction();
    	Query q=session.createQuery(sqlQuery1);
    	q.setParameter(0, username);
    	List result=q.list();
    	String status="";
    	for(int i=0;i<result.size();i++)
    	{
    		status=(String)result.get(0);
    		
    	}
    	return status;
    	
    }
}
